//
//  SMStateMachine.h
//  SMStateMachine
//
//  Created by Werner on 1/7/11.
//  Copyright 2011 Cultured Code. All rights reserved.
//

#import <Foundation/Foundation.h>

/*

   General idea of state machines:
 - Move if/elif/else branches into states.
 - Without SM, every actionMethod by default *always* executes the code. Lots of "if(..)return;" needed if we add new behavior. With SM, by default, nothing happens, enable it only for states where needed.


   Design Goals:
 - Compatibility with older iOS / MacOS, otherwise blocks!
 - Incorporate many principles from HSM, but don't convolute with too much functionality. I.e. simple things should be simple.
 - Make it very easy to add new states, events, guards.


   Deviations from HSM:
 - No polymorphism in events
 - Not every hierachical state needs to have an initial transition
 - Transitions from a superstate to a substate are local (as opposed to external). There is no external transition support.


   Limitations:
 - The machine does not support transition code on any transition pointing into an SMBranch. This causes logical problems because it is not
   clear if the branch will be taken or not until it is evaulated. By this time, any code on the transition has already been run, even if the
   branch is not taken.

   It is fine to have transition code on transitions leaving a branch.


   TODO:
 - Support SM...Ext() methods, where you can also specify the machine name
 - Think about: Transient States have the property that: all their branches either have no action or end with an automatic one. Look at smStateDispatchEvent for an example?
*/


@class SMMachine;
@class SMTestLog;

typedef enum {
    _SMRequestTypeInitialState,
    _SMRequestTypeState,
    _SMRequestTypeBranch,
    _SMRequestTypeNodeType,
} _SMRequestType;

typedef enum {
    _SMSubRequestTypeName,
    _SMSubRequestTypeParent,
    _SMSubRequestTypeInitialSubstate,
    _SMSubRequestTypeEnter,
    _SMSubRequestTypeAfterEnter,
    _SMSubRequestTypeExit,
    _SMSubRequestTypeBeforeExit,
    _SMSubRequestTypeOnEvent,
    _SMSubRequestTypeRespondsToEvent,
    _SMSubRequestTypeBranchDestination,
} _SMSubRequestType;

typedef enum {
    _SMNodeTypeState,
    _SMNodeTypeBranch,
} _SMNodeType;

typedef struct {
    SMMachine * __unsafe_unretained machine;
    _SMRequestType requestType;
    NSInteger state; // TODO: consider renaming to 'node'
    _SMSubRequestType subRequestType;
    NSInteger event;
    id __unsafe_unretained eventInfo;
    BOOL handled;
} _SMRequest;

enum {SMNoState = NSIntegerMax};
enum {SMNoEvent = NSIntegerMax};
enum {SMNoNodeType = NSIntegerMax};


@interface SMMachine : NSObject
{
    // Internals
    NSInteger smInternalState_;

    SMTestLog *log_;
    NSMutableArray *internalEventQueue_;

    NSString *name_;

    id __unsafe_unretained smRequestTarget_;
    SEL smRequestSelector_;

    // Modeled State Machine
    NSInteger state_;
    NSInteger transitionSourceState_;
    NSInteger transitionTargetState_;
    NSInteger event_;
    id <NSObject> __weak eventInfo_;
}

@property (nonatomic, unsafe_unretained) id  requestTarget; // It is important that this remains a unsafe_unretained reference, since otherwise we won't be able to call machine methods in dealloc of the target anymore (which we might want to do, e.g. to send eventDealloc to the machine). The reason for this is that weak references to an object A are nilled out _before_ dealloc is called on A.
@property (nonatomic, assign) SEL requestSelector;

@property (nonatomic, assign, readonly) NSInteger state;

@property (nonatomic, strong, readonly) SMTestLog *log;

@property (nonatomic, strong, readonly) NSString *name;

- (id)initWithRequestTarget:(id)target selector:(SEL)selector name:(NSString *)name;

// Start and run the machine. Should only be called on the main thread.
- (void)start;

// Post an event to the machine. Should only be called from the main thread.
- (void)postEvent:(NSInteger)event;

// Post an event to the machine with a parameter. Should only be called from the main thread.
- (void)postEvent:(NSInteger)event info:(id <NSObject>)info;

// Post an event to the machine in the form of an NSNumber *. This is to allow it to be called from the
// performSelector: style methods that require an object parameter. Should only be called from the main thread.
- (void)postEventNumber:(NSNumber *)event;

// Debugging
- (NSString *)nameOfState:(NSInteger)state;


// Post an event to the machine in the form of an NSNumber * with a parameter. This is to allow it to be called
// from the performSelector: style methods that require an object parameter. Should only be called from the main thread.
- (void)postEventNumber:(NSNumber *)event info:(id <NSObject>)info;

// Internal Events
- (void)_beginTransitionFromSourceState:(NSNumber *)sourceStateNumber toTargetState:(NSNumber *)targetStateNumber;
- (void)_endTransitionFromSourceState:(NSNumber *)sourceStateNumber toTargetState:(NSNumber *)targetStateNumber;

// Internal methods
- (BOOL)_validateInitialSubstateRequest:(_SMRequest *)request forSubstate:(NSInteger)substate;

@end


// Returns an object with +1 retain as implied by the 'create' in the name.
#define SMMachineCreate(machineName) \
[[SMMachine alloc] initWithRequestTarget:self selector:@selector(_sm_##machineName##_handleRequest:) name:@#machineName];


#define SMAssert(machineName, event, stateName) \
XCTAssertTrue([machineName.log should##event##State: stateName]);


#define SMStates(...) \
enum {__VA_ARGS__};

#define SMEvents(...) \
enum {__VA_ARGS__};


#define SMDeclareChart(machineName) \
- (nullable id)_sm_##machineName##_handleRequest:(_SMRequest *)request;

#define SMDeclareChartWithoutNullabilityAnnotations(machineName) \
- (id)_sm_##machineName##_handleRequest:(_SMRequest *)request;

#define SMBeginChart(machineName) \
\
- (id)_sm_##machineName##_handleRequest:(_SMRequest *)request \
{ \
NSString *_sm_machineName = @#machineName; \
_sm_machineName = _sm_machineName;\
NSInteger _sm_transitionSourceState = SMNoState;


#ifdef __clang_analyzer__
# define SMEndChart \
    NSAssert(NO, nil); \
    return nil; \
}
#else
# define SMEndChart \
    return nil; \
}
#endif


#define SMBeginExtensionChart(machineName) \
\
- (id)_sm_##machineName##_handleRequest:(_SMRequest *)request \
{ \
NSString *_sm_machineName = @#machineName; \
_sm_machineName = _sm_machineName;\
NSInteger _sm_transitionSourceState = SMNoState;


#define SMEndExtensionChart(machineName) \
NSAssert([_sm_machineName isEqualToString:@#machineName], @"");\
return [super _sm_##machineName##_handleRequest:request]; \
}



#define SMInitialState(stateName) \
if (!(request->handled) && request->requestType == _SMRequestTypeInitialState && (request->handled=YES)==YES) { \
    return [NSNumber numberWithInteger:stateName]; \
}


#define SMBranch(branchName) \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Wdangling-else\"") \
if (!(request->handled) && request->requestType == _SMRequestTypeNodeType && request->state == branchName && (request->handled=YES)==YES) return [NSNumber numberWithInteger:_SMNodeTypeBranch]; \
if (!(request->handled) && request->requestType == _SMRequestTypeBranch && request->state == branchName) \
    if (request->subRequestType == _SMSubRequestTypeName  && (request->handled=YES)==YES) return @#branchName; \
    else \
_Pragma("clang diagnostic pop")


#define SMState(stateName) \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Wdangling-else\"") \
_sm_transitionSourceState = stateName; \
if (!(request->handled) && request->requestType == _SMRequestTypeNodeType && request->state == stateName  && (request->handled=YES)==YES) return [NSNumber numberWithInteger:_SMNodeTypeState]; \
if (!(request->handled) && request->requestType == _SMRequestTypeState && request->state == stateName) \
    if (request->subRequestType == _SMSubRequestTypeName && (request->handled=YES)==YES) return @#stateName; \
    else \
_Pragma("clang diagnostic pop")


#define SMParent(parentName) \
    if (!(request->handled) && request->subRequestType == _SMSubRequestTypeParent && (request->handled=YES)==YES) return [NSNumber numberWithInteger:parentName];


#define SMInitialSubstate(substateName) \
    do { \
        if (!(request->handled) && request->subRequestType == _SMSubRequestTypeInitialSubstate && (request->handled=YES)==YES) { \
            NSAssert([request->machine _validateInitialSubstateRequest:request forSubstate:substateName], \
            @"The initial substate of a state must be one of its direct children states."); \
            return [NSNumber numberWithInteger:substateName]; \
        } \
    } while (0)


#define SMEnter() \
    if (!(request->handled) && request->subRequestType == _SMSubRequestTypeEnter && (request->handled=YES)==YES)


#define SMAfterEnter() \
    if (!(request->handled) && request->subRequestType == _SMSubRequestTypeAfterEnter && (request->handled=YES)==YES)


#define SMBeforeExit() \
    if (!(request->handled) && request->subRequestType == _SMSubRequestTypeBeforeExit && (request->handled=YES)==YES)


#define SMExit() \
    if (!(request->handled) && request->subRequestType == _SMSubRequestTypeExit && (request->handled=YES)==YES)


#define SMOnEvent(eventName) \
    if      (!(request->handled) && request->subRequestType == _SMSubRequestTypeRespondsToEvent && request->event == eventName && (request->handled=YES)==YES) return [NSNumber numberWithBool:YES]; \
    else if (!(request->handled) && request->subRequestType == _SMSubRequestTypeOnEvent         && request->event == eventName && (request->handled=YES)==YES)

#define SMEventBreak() return nil

#define SMEventInfo() \
    (request->eventInfo)

#define SMSuperOnEvent(eventName) \
    do { \
       NSAssert(request->requestType == _SMRequestTypeState && request->subRequestType == _SMSubRequestTypeOnEvent && request->event == eventName, @""); \
       request->handled = NO; \
    } while (0)

#define SMTransitionTo(stateName, ...) \
    do { \
        [request->machine _beginTransitionFromSourceState:@(_sm_transitionSourceState) toTargetState:@(stateName)]; \
        { \
            __VA_ARGS__ \
        } \
        [request->machine _endTransitionFromSourceState:@(_sm_transitionSourceState) toTargetState:@(stateName)]; \
    } while (0)

#define SMTransitionToAndExecuteBefore(stateName, ...) \
    do { \
        { \
            __VA_ARGS__ \
        } \
        [request->machine _beginTransitionFromSourceState:@(_sm_transitionSourceState) toTargetState:@(stateName)]; \
        [request->machine _endTransitionFromSourceState:@(_sm_transitionSourceState) toTargetState:@(stateName)]; \
    } while (0)

#define SMTransitionToStateAndExecuteAfter(stateName, ...) \
    do { \
        [request->machine _beginTransitionFromSourceState:@(_sm_transitionSourceState) toTargetState:@(stateName)]; \
        [request->machine _endTransitionFromSourceState:@(_sm_transitionSourceState) toTargetState:@(stateName)]; \
        { \
            __VA_ARGS__ \
        } \
    } while (0)


//SMBeginMachine(machine) {
//
//    SMInitialState(Normal);
//
//
//    SMState(Normal) {
//
//        SMParent(Parent);
//
//        SMInitialSubstate(Substate);
//
//        SMEnter() {
//        }
//
//        SMExit() {
//        }
//
//        SMOnEvent(mouseDown) {
//            SMTransitionTo(Selected);
//        }
//
//        SMOnEvent(mouseUp) {
//            SMTransitionTo(Selected, {
//                // transition code
//            });
//        }
//
//        SMOnEvent(mouseMoved) {
//            SMInternalTransition();
//        }
//
//        SMOnEvent(mouseWheel) {
//            SMInternalTransition({
//                // transition code
//            });
//        }
//    }
//
//
//    SMState(Selected) {
//
//        SMOnEvent(mouseDown) {
//            a = 1;
//            SMTransitionTo(checkSomething);
//        }
//    }
//
//    SMBranch(checkSomething) {
//        if (a == 1) return [NSNumber numberWithInteger:Normal];
//        else return nil;
//    }
//
//
//} SMEndMachine();
//
//





//// This is how the subclasses can refine behavior
//SMMachine(machine) {
//
//    SMState(Normal) {
//        SMOnEvent(mouseDown, info) {
//            SMTransitionTo(Selected);
//        }
//    }
//
//    SMEndMachine();
//}
//    // This calls super, if it responds to machineHandleRequest:, otherwise returns nil. This way, we can even inherit state behavior! and modify it slightly in subclasses!
//    // See code below. For that, the default above needs to go away (which is good!)
//
